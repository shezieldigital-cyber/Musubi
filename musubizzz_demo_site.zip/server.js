const express=require("express");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const path=require("path");
const app=express(), db=new Database(path.join(__dirname,"data","musubizzz.sqlite"));
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||"change-me",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",maxAge:28800000}}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user',
 demo_balance REAL NOT NULL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reward_events(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,product_id INTEGER NOT NULL,
 kind TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id));
`);
const products=[
 {id:1,name:"Musubi 300",price:300,daily:60,signin:5,duration:30},
 {id:2,name:"Musubi 500",price:500,daily:135,signin:0,duration:30},
 {id:3,name:"Musubi 800",price:800,daily:210,signin:0,duration:30}
];
const seed=db.prepare("SELECT id FROM users WHERE email=?").get("admin@musubizzz.local");
if(!seed) db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
 .run("Admin","admin@musubizzz.local",bcrypt.hashSync("Admin123!",12),"admin");

function auth(req,res,next){if(!req.session.userId)return res.status(401).json({error:"Please log in."});next()}
app.get("/api/products",(req,res)=>res.json({products}));
app.post("/api/register",async(req,res)=>{
 const name=String(req.body.name||"").trim(),email=String(req.body.email||"").trim().toLowerCase(),pw=String(req.body.password||"");
 if(name.length<2||!email.includes("@")||pw.length<8)return res.status(400).json({error:"Use a valid name, email, and 8+ character password."});
 try{const r=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name,email,await bcrypt.hash(pw,12));req.session.userId=r.lastInsertRowid;res.json({ok:true})}
 catch(e){res.status(400).json({error:"Email already registered."})}
});
app.post("/api/login",async(req,res)=>{
 const email=String(req.body.email||"").toLowerCase().trim(),u=db.prepare("SELECT * FROM users WHERE email=?").get(email);
 if(!u||!(await bcrypt.compare(String(req.body.password||""),u.password_hash)))return res.status(401).json({error:"Invalid login."});
 req.session.userId=u.id;res.json({ok:true});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",auth,(req,res)=>{
 const u=db.prepare("SELECT id,name,email,role,demo_balance,created_at FROM users WHERE id=?").get(req.session.userId);
 res.json({user:u});
});
app.post("/api/demo-buy",auth,(req,res)=>{
 const p=products.find(x=>x.id===Number(req.body.productId));
 if(!p)return res.status(400).json({error:"Product not found."});
 db.prepare("INSERT INTO reward_events(user_id,product_id,kind,amount) VALUES(?,?,?,?)")
   .run(req.session.userId,p.id,"demo_purchase",p.price);
 res.json({ok:true,message:`Demo purchase selected: ${p.name}. No real payment was taken.`});
});
app.post("/api/demo-signin",auth,(req,res)=>{
 const p=products.find(x=>x.id===1);
 db.prepare("INSERT INTO reward_events(user_id,product_id,kind,amount) VALUES(?,?,?,?)")
   .run(req.session.userId,p.id,"demo_sign_in_reward",p.signin);
 res.json({ok:true,message:`Demo sign-in reward: ₱${p.signin.toFixed(2)}. This is simulation data only.`});
});
app.get("/api/admin/users",auth,(req,res)=>{
 const u=db.prepare("SELECT role FROM users WHERE id=?").get(req.session.userId);
 if(!u||u.role!=="admin")return res.status(403).json({error:"Admin only."});
 res.json({users:db.prepare("SELECT id,name,email,role,demo_balance,created_at FROM users ORDER BY id DESC").all()});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Musubizzz demo running"));
